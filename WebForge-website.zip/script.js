const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('show'); });
}, {threshold:.12});
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

const menu = document.querySelector('.menu');
const links = document.querySelector('.nav-links');
menu?.addEventListener('click', () => {
  const open = menu.getAttribute('aria-expanded') === 'true';
  menu.setAttribute('aria-expanded', String(!open));
  links.style.display = open ? '' : 'flex';
  if (!open) {
    links.style.position='absolute'; links.style.top='76px'; links.style.left='0'; links.style.right='0';
    links.style.padding='20px'; links.style.background='#0a0a0c'; links.style.flexDirection='column'; links.style.gap='20px';
  }
});
links?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  if (window.innerWidth <= 800) { links.style.display='none'; menu.setAttribute('aria-expanded','false'); }
}));

document.querySelector('#contactForm')?.addEventListener('submit', e => {
  e.preventDefault();
  const form=e.currentTarget, status=form.querySelector('.form-status');
  if (!form.checkValidity()) { status.textContent='Please fill in all fields correctly.'; form.reportValidity(); return; }
  const data = new FormData(form);
  const subject = encodeURIComponent('WebForge project enquiry');
  const body = encodeURIComponent(`Name: ${data.get('name')}\nEmail: ${data.get('email')}\n\nProject:\n${data.get('message')}`);
  status.textContent='Your brief is ready — opening your email app…';
  window.location.href=`mailto:?subject=${subject}&body=${body}`;
});
