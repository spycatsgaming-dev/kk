# WebForge website
A responsive static website for a website-building studio.

## Files
- index.html — page structure
- style.css — responsive styling and animations
- script.js — scroll reveals, mobile menu, contact form

## Deploy
Upload these files to a GitHub repository and enable GitHub Pages.
No build step is required.

## Important
The contact form uses the visitor's default email app (`mailto:`), so replace it in `script.js` with your business email if desired.
